package com.example.myapplication.Function;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.example.myapplication.AlwaysTopServiceTouch;
import com.example.myapplication.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

public class PaintActivity extends Activity {
    private MediaProjectionManager mediaProjectionManager;
    private ImageReader mImageReader;
    private String mImagePath;
    private WindowManager mWindowManager;
    private int mWindowWidth;
    private int mWindowHeight;
    private int mScreenDensity;
    private Intent it;
    private String mImageName;
    private static final String TAG = "MainActivity";
    private Bitmap mBitmap;
    private VirtualDisplay mVirtualDisplay;
    private int pointx = 0;
    private int pointy = 0;

    private boolean isTouched;

    private SingleTouchView singleTouchView;
    private BroadcastReceiver br_paintAcitivity_close, br_getPoint;

    private LinearLayout linearLayout_paint;
    private TextView txt_thickness;
    private View btn_colorRed, btn_colorBlue, btn_colorBlack;
    private ImageView imgbtn_thickUp, imgbtn_thickDown;
    private ImageView imgbtn_save;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (br_paintAcitivity_close != null) {
            unregisterReceiver(br_paintAcitivity_close);
        }
        if (br_getPoint != null) {
            unregisterReceiver(br_getPoint);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (br_paintAcitivity_close == null) {
            br_paintAcitivity_close = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    finish();
                    overridePendingTransition(0, 0);
                }
            };
        }

        if (br_getPoint == null) {
            br_getPoint = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    boolean isPaint = intent.getBooleanExtra("paint", false);
                    boolean isDetached = intent.getBooleanExtra("detach", false);
                    long downTime = SystemClock.uptimeMillis();
                    long eventTime = SystemClock.uptimeMillis();

                    int metaState = 0;

                    if (isPaint) {
                        if (!onTouchPaint(pointx, pointy)) {
                            if (isDetached == true && pointx > 0 && pointy > 0) {
                                final MotionEvent motionEventUp = MotionEvent.obtain(
                                        downTime,
                                        eventTime,
                                        MotionEvent.ACTION_UP,
                                        pointx,
                                        pointy,
                                        metaState
                                );
                                singleTouchView.dispatchTouchEvent(motionEventUp);
                                isTouched = false;
                            } else if (isDetached == false && isTouched == false) {

                                pointx = intent.getIntExtra("point_x", -1);
                                pointy = intent.getIntExtra("point_y", -1);
                                if (pointx > 0 && pointy > 0) {
                                    isTouched = true;
                                    final MotionEvent motionEventDown = MotionEvent.obtain(
                                            downTime,
                                            eventTime,
                                            MotionEvent.ACTION_DOWN,
                                            pointx,
                                            pointy,
                                            metaState
                                    );
                                    singleTouchView.dispatchTouchEvent(motionEventDown);
                                }
                            }
                            if (isDetached == false && isTouched == true) {

                                pointx = intent.getIntExtra("point_x", -1);
                                pointy = intent.getIntExtra("point_y", -1);
                                if (pointx > 0 && pointy > 0) {
                                    final MotionEvent motionEventMove = MotionEvent.obtain(
                                            downTime,
                                            eventTime,
                                            MotionEvent.ACTION_MOVE,
                                            pointx,
                                            pointy,
                                            metaState
                                    );
                                    singleTouchView.dispatchTouchEvent(motionEventMove);
                                }
                            }
                        }
                    }
                }
            };
        }

        registerReceiver(br_getPoint, new IntentFilter("point"));
        registerReceiver(br_paintAcitivity_close, new IntentFilter("paintAcitivity_close"));

    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.O_MR1)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        singleTouchView = new SingleTouchView(this, null);
        setContentView(singleTouchView);

        init();

        singleTouchView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                int x = (int) event.getX();
                int y = (int) event.getY();

                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    onTouchPaint(x, y);
                }

                Log.d("페인트 좌표",x + " " + y);

                return false;
            }
        });

    }

    private boolean onTouchPaint(int x, int y) {
       if (x >= 1600 && x <= 1730) {
            if (y >= 920 && y <= 1040) {
                linearLayout_paint.setVisibility(View.INVISIBLE);
                AlwaysTopServiceTouch.mView.setVisibility(View.INVISIBLE);
                startActivityForResult(it, 666);
            }
            return true;
        } else if ((x >= 1800 && x <= 1890)) {
            /* Color Change */
            if ((y >= 150 && y <= 280)) {
                Toast.makeText(PaintActivity.this, "색상 변경 : 노랑", Toast.LENGTH_SHORT).show();
                singleTouchView.colorChange(0xFF98812B);
            } else if ((y >= 300 && y <= 400)) {
                Toast.makeText(PaintActivity.this, "색상 변경 : 파랑", Toast.LENGTH_SHORT).show();
                singleTouchView.colorChange(0xFF3C7583);
            } else if ((y >= 420 && y <= 520)) {
                Toast.makeText(PaintActivity.this, "색상 변경 : 연두", Toast.LENGTH_SHORT).show();
                singleTouchView.colorChange(0xFF4C751E);
            }
            /*Thickness Change */
            else if (y >= 820 && y <= 900) {
                SingleTouchView.width_size += 1;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            txt_thickness.setText(String.valueOf(SingleTouchView.width_size));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                singleTouchView.setStrokeWidth(SingleTouchView.width_size);
            } else if (y >= 930 && y <= 1030) {
                SingleTouchView.width_size -= 1;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            txt_thickness.setText(String.valueOf(SingleTouchView.width_size));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                singleTouchView.setStrokeWidth(SingleTouchView.width_size);
            }
            return true;
        } else {
            return false;
        }
    }

    private boolean onTouchBluetoothPaint(int x, int y) {
        if (x >= 1600 && x <= 1730) {
            if (y >= 920 && y <= 1040) {
                linearLayout_paint.setVisibility(View.INVISIBLE);
                AlwaysTopServiceTouch.mView.setVisibility(View.INVISIBLE);
                startActivityForResult(it, 666);
            }
            return true;
        } else if ((x >= 1800 && x <= 1890)) {
            /* Color Change */
            if ((y >= 150 && y <= 280)) {
                Toast.makeText(PaintActivity.this, "색상 변경 : 노랑", Toast.LENGTH_SHORT).show();
                singleTouchView.colorChange(0xFF98812B);
            } else if ((y >= 230 && y <= 300)) {
                Toast.makeText(PaintActivity.this, "색상 변경 : 파랑", Toast.LENGTH_SHORT).show();
                singleTouchView.colorChange(0xFF3C7583);
            } else if ((y >= 390 && y <= 470)) {
                Toast.makeText(PaintActivity.this, "색상 변경 : 연두", Toast.LENGTH_SHORT).show();
                singleTouchView.colorChange(0xFF4C751E);
            }
            /*Thickness Change */
            else if (y >= 750 && y <= 850) {
                SingleTouchView.width_size += 1;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            txt_thickness.setText(String.valueOf(SingleTouchView.width_size));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                singleTouchView.setStrokeWidth(SingleTouchView.width_size);
            } else if (y >= 900 && y <= 970) {
                SingleTouchView.width_size -= 1;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            txt_thickness.setText(String.valueOf(SingleTouchView.width_size));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
                singleTouchView.setStrokeWidth(SingleTouchView.width_size);
            }
            return true;
        } else {
            return false;
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.O_MR1)
    @SuppressLint("WrongConstant")
    private void init() {
        mediaProjectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        it = mediaProjectionManager.createScreenCaptureIntent();
        mImagePath = Environment.getExternalStorageDirectory() + "/Download/";
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowWidth = mWindowManager.getDefaultDisplay().getWidth();
        mWindowHeight = mWindowManager.getDefaultDisplay().getHeight();
        mImageReader = ImageReader.newInstance(mWindowWidth, mWindowHeight, 0x1, 2);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        mWindowManager.getDefaultDisplay().getMetrics(displayMetrics);
        mScreenDensity = displayMetrics.densityDpi;


        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = inflater.inflate(R.layout.paint_main, null);
        addContentView(v, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        btn_colorRed = v.findViewById(R.id.btn_paint_colorRed);
        btn_colorBlack = v.findViewById(R.id.btn_paint_colorBlack);
        btn_colorBlue = v.findViewById(R.id.btn_paint_colorBlue);

        imgbtn_thickUp = v.findViewById(R.id.imgbtn_paint_thickUp);
        imgbtn_thickDown = v.findViewById(R.id.imgbtn_paint_thickDown);
        imgbtn_save = v.findViewById(R.id.imgbtn_paint_save);

        txt_thickness = v.findViewById(R.id.txt_paint_thickness);
        txt_thickness.setText(String.valueOf(SingleTouchView.width_size));

        linearLayout_paint = v.findViewById(R.id.linearlayout_paint);

        isTouched = false;

    }


    @RequiresApi(api = Build.VERSION_CODES.O_MR1)
    private void startCapture() {
        mImageName = "screenshot" + System.currentTimeMillis() + ".png";
        Log.i(TAG, "image name is : " + mImageName);
        Image image = mImageReader.acquireLatestImage();
        if (image == null) {
            Log.e(TAG, "image is null.");
            return;
        }
        int width = image.getWidth();
        int height = image.getHeight();
        final Image.Plane[] planes = image.getPlanes();
        final ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * width;

        mBitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
        mBitmap.copyPixelsFromBuffer(buffer);
        mBitmap = Bitmap.createBitmap(mBitmap, 0, 0, width, height);
        image.close();

        stopScreenCapture();
        saveToFile();
    }

    @RequiresApi(api = Build.VERSION_CODES.O_MR1)
    private void stopScreenCapture() {
        if (mVirtualDisplay != null) {

            mVirtualDisplay.release();
            mVirtualDisplay = null;
        }
    }

    private void saveToFile() {
        try {

            File fileFolder = new File(mImagePath);
            if (!fileFolder.exists())
                fileFolder.mkdirs();
            File file = new File(mImagePath, mImageName);
            if (!file.exists()) {
                Log.d(TAG, "file create success ");
                file.createNewFile();
            }
            FileOutputStream out = new FileOutputStream(file);
            mBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            out.close();
            Log.d(TAG, "file save success ");
            Toast.makeText(this.getApplicationContext(), "이미지 저장 완료", Toast.LENGTH_SHORT).show();

            linearLayout_paint.setVisibility(View.VISIBLE);
            AlwaysTopServiceTouch.mView.setVisibility(View.VISIBLE);
        } catch (IOException e) {
            Log.e(TAG, e.toString());
            Toast.makeText(this.getApplicationContext(), "이미지 저장 실패", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O_MR1)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        MediaProjection mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data);
        if (null != mediaProjection) {

            mVirtualDisplay = mediaProjection.createVirtualDisplay("ScreenCapture", mWindowWidth, mWindowHeight, mScreenDensity, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, mImageReader.getSurface(), null, null);
            startCapture();
        }
    }
}
