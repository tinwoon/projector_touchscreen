package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.example.myapplication.Function.LoadActivity;
import com.example.myapplication.Function.NaverActivity;
import com.example.myapplication.Function.PaintActivity;
import com.example.myapplication.Function.PdfActivity;
import com.example.myapplication.Function.YoutubeActivity;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class AlwaysTopServiceTouch extends Service {

    // foreground

    public static View mView;
    private WindowManager mManager;
    private WindowManager.LayoutParams mParams;

    private ImageView fab_main, fab_youtube, fab_naver, fab_pdf, fab_paint, fab_up, fab_down;
    private ImageView fab_load;
    private Animation fab_open, fab_close;

    private String current_class;

    private boolean isFabOpen = false;
    private boolean isPaintOpen = false;
    private boolean isPdfOpen = false;
    private boolean isLoadOpen = false;

    /* Bluetooth 부분 */
    private final int REQUEST_BLUETOOTH_ENABLE = 100;

    ConnectedTask mConnectedTask = null;
    static BluetoothAdapter mBluetoothAdapter;
    private String mConnectedDeviceName = null;
    private ArrayAdapter<String> mConversationArrayAdapter;
    static boolean isConnectionError = false;
    private static final String TAG = "BluetoothClient";

    private int x = 0;
    private int y = 0;
    private int cnt;

    /* Toast */
    private Handler toastHandler;

    private class ToastRunnable implements Runnable {
        String mText;

        public ToastRunnable(String text) {
            mText = text;
        }

        @Override
        public void run() {
            Toast.makeText(getApplicationContext(), mText, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();

        init();
        bluetoothSet();

        int layout_parms;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layout_parms = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        } else {

            layout_parms = WindowManager.LayoutParams.TYPE_PHONE;

        }

        mParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layout_parms,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        // 플러팅 버튼 위치
        mParams.gravity = Gravity.BOTTOM | Gravity.LEFT;

        mView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                int pointx = (int) event.getX();
                int pointy = (int) event.getY();

                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    clickFabButton(pointx, pointy);
                }
                //Log.d("플러팅 좌표" , pointx + " " + pointy);
                return false;
            }
        });

        mManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mManager.addView(mView, mParams);
    }

    private boolean clickBluetooth(int x, int y){
        if (y >= 850 && y <= 1100){
            if (x >= 70 && x <= 150)  {
                toggleFab();
            } else if (isFabOpen == true) {
                if ( x >= 200 && x <= 320) {

                    if (isPaintOpen) {
                        toggleFab();
                        sendBroadcast(new Intent("paintAcitivity_close"));
                        isPaintOpen = false;
                    } else {
                        Intent paint_intent = new Intent(getApplicationContext(), PaintActivity.class);
                        startActivity(paint_intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        // Toast.makeText(getApplicationContext(), "그리기 기능 ON", Toast.LENGTH_SHORT).show();
                        isPaintOpen = true;
                    }
                } else if (x >= 350 && x <= 430) {
                    toggleFab();
                    if (isPdfOpen) {
                        toggleFab();
                        sendBroadcast(new Intent("pdfActivity_close"));
                        isPdfOpen = false;
                    }  else {
                        Intent pdf_intent = new Intent(getApplicationContext(), PdfActivity.class);
                        startActivity(pdf_intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        isPdfOpen = true;
                        // Toast.makeText(getApplicationContext(), "Pdf에 연결합니다.", Toast.LENGTH_SHORT).show();
                    }
                } else if (x >= 520 && x <= 610) {
                    if (isLoadOpen) {
                        toggleFab();
                        sendBroadcast(new Intent("loadActivity_close"));
                        isLoadOpen = false;
                    } else {
                        Intent load_intent = new Intent(getApplicationContext(), LoadActivity.class);
                        startActivity(load_intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        isLoadOpen = true;
                    }
                }
            }
            return true;
        } else {
            return false;
        }
    }

    private boolean clickFabButton(int x, int y) {
        if (y >= 20 && y <= 115){
            if (x >= 100 && x <= 220)  {
                toggleFab();
            } else if (isFabOpen == true) {
                if ( x >= 290 && x <= 410) {

                    if (isPaintOpen == false) {
                        Intent paint_intent = new Intent(getApplicationContext(), PaintActivity.class);
                        startActivity(paint_intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        //Toast.makeText(getApplicationContext(), "그리기 기능 ON", Toast.LENGTH_SHORT).show();
                        isPaintOpen = true;
                    } else {
                        toggleFab();
                        sendBroadcast(new Intent("paintAcitivity_close"));
                        isPaintOpen = false;
                    }
                } else if (x >= 460 && x <= 550) {
                    toggleFab();
                    getCurrentClass();
                    if (current_class.equals("com.example.myapplication.Function.PdfActivity")) {
                        toggleFab();
                        sendBroadcast(new Intent("pdfActivity_close"));
                    } else {
                        Intent pdf_intent = new Intent(getApplicationContext(), PdfActivity.class);
                        startActivity(pdf_intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        //Toast.makeText(getApplicationContext(), "Pdf에 연결합니다.", Toast.LENGTH_SHORT).show();
                    }
                } else if (x >= 575 && x <= 740) {
                    toggleFab();

                    getCurrentClass();
                    if (current_class.equals("com.example.myapplication.Function.LoadActivity")) {
                        toggleFab();
                        sendBroadcast(new Intent("loadActivity_close"));
                    } else {
                        Intent load_intent = new Intent(getApplicationContext(), LoadActivity.class);
                        startActivity(load_intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    }
                }
            }
            return true;
        } else {
            return false;
        }

    }


    // 변수 초기화
    @SuppressLint("ClickableViewAccessibility")
    public void init() {

        cnt = 0;

        LayoutInflater mInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mView = mInflater.inflate(R.layout.always_on_top_view_touch, null);

        fab_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_open);
        fab_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_close);

        fab_main = (ImageView) mView.findViewById(R.id.fab_main);/*
        fab_youtube = (ImageView) mView.findViewById(R.id.fab_youtube);
        fab_naver = (ImageView) mView.findViewById(R.id.fab_naver);*/
        fab_pdf = (ImageView) mView.findViewById(R.id.fab_pdf);
        fab_paint = (ImageView) mView.findViewById(R.id.fab_paint);/*
        fab_up = mView.findViewById(R.id.fab_up);
        fab_down = mView.findViewById(R.id.fab_down);*/
        fab_load = mView.findViewById(R.id.fab_load);


        toastHandler = new Handler();

    }


    /* 블루투스 초기화 */
    public void bluetoothSet() {
        Log.d(TAG, "Initalizing Bluetooth adapter...");

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (mBluetoothAdapter == null) {
            showErrorDialog("This device is not implement Bluetooth.");
            return;
        }

        if (!mBluetoothAdapter.isEnabled()) {
            showPairedDevicesListDialog();
        } else {
            Log.d(TAG, "Initialisation successful.");

            showPairedDevicesListDialog();
        }
    }

    // 현재 실행중인 액티비티(클래스) 이름을 알아오는 함수
    public void getCurrentClass() {
        ActivityManager AM = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> Info = AM.getRunningTasks(1);
        ComponentName topActivity = Info.get(0).topActivity;
        current_class = topActivity.getClassName();
    }

    private void toggleFab() {

        if (isFabOpen) {
            fab_main.setImageResource(R.drawable.ic_fab);
            fab_pdf.startAnimation(fab_close);
            fab_paint.startAnimation(fab_close);/*
            fab_up.startAnimation(fab_close);
            fab_down.startAnimation(fab_close);*/
            fab_load.startAnimation((fab_close));
            isFabOpen = false;

        } else {
            fab_main.setImageResource(R.drawable.ic_fab_close);
            fab_pdf.startAnimation(fab_open);
            fab_paint.startAnimation(fab_open);
/*            fab_up.startAnimation(fab_open);
            fab_down.startAnimation(fab_open);*/
            fab_load.startAnimation(fab_open);

            isFabOpen = true;

        }

    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mView != null) {
            mManager.removeView(mView);
            mView = null;
        }
    }

    @Override
    public IBinder onBind(Intent arg0) {
        return null;
    }

    /* 블루투스 부분 */

    private class ConnectTask extends AsyncTask<Void, Void, Boolean> {

        private BluetoothSocket mBluetoothSocket = null;
        private BluetoothDevice mBluetoothDevice = null;

        ConnectTask(BluetoothDevice bluetoothDevice) {
            mBluetoothDevice = bluetoothDevice;
            mConnectedDeviceName = bluetoothDevice.getName();

            //SPP
            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

            try {
                mBluetoothSocket = mBluetoothDevice.createRfcommSocketToServiceRecord(uuid);
                Log.d(TAG, "create socket for " + mConnectedDeviceName);

            } catch (IOException e) {
                Log.e(TAG, "socket create failed " + e.getMessage());
            }
        }


        @Override
        protected Boolean doInBackground(Void... params) {

            // Always cancel discovery because it will slow down a connection
            mBluetoothAdapter.cancelDiscovery();

            // Make a connection to the BluetoothSocket
            try {
                // This is a blocking call and will only return on a
                // successful connection or an exception
                mBluetoothSocket.connect();
            } catch (IOException e) {
                // Close the socket
                try {
                    mBluetoothSocket.close();
                } catch (IOException e2) {
                    Log.e(TAG, "unable to close() " +
                            " socket during connection failure", e2);
                }

                return false;
            }

            return true;
        }


        @Override
        protected void onPostExecute(Boolean isSucess) {

            if (isSucess) {
                connected(mBluetoothSocket);
            } else {

                isConnectionError = true;
                Log.d(TAG, "Unable to connect device");
                showErrorDialog("Unable to connect device");
            }
        }
    }


    public void connected(BluetoothSocket socket) {
        mConnectedTask = new ConnectedTask(socket);
        mConnectedTask.execute();
    }


    private class ConnectedTask extends AsyncTask<Void, String, Boolean> {

        private InputStream mInputStream = null;
        private OutputStream mOutputStream = null;
        private BluetoothSocket mBluetoothSocket = null;

        ConnectedTask(BluetoothSocket socket) {

            mBluetoothSocket = socket;
            try {
                mInputStream = mBluetoothSocket.getInputStream();
                mOutputStream = mBluetoothSocket.getOutputStream();
            } catch (IOException e) {
                Log.e(TAG, "socket not created", e);
            }

            Log.d(TAG, "connected to " + mConnectedDeviceName);
        }


        /* 여기서 받음! */
        @Override
        protected Boolean doInBackground(Void... params) {

            byte[] readBuffer = new byte[1024];
            int readBufferPosition = 0;


            while (true) {

                if (isCancelled()) return false;

                try {

                    int bytesAvailable = mInputStream.available();

                    if (bytesAvailable > 0) {

                        byte[] packetBytes = new byte[bytesAvailable];

                        mInputStream.read(packetBytes);

                        for (int i = 0; i < bytesAvailable; i++) {
                            byte b = packetBytes[i];
                            if (b == '\n') {
                                byte[] encodedBytes = new byte[readBufferPosition];
                                System.arraycopy(readBuffer, 0, encodedBytes, 0,
                                        encodedBytes.length);
                                String recvMessage = new String(encodedBytes, "UTF-8");

                                char[] arrChar = recvMessage.toCharArray();

                                Intent point_intent = new Intent("point");

                                // 손가락 떼었을 때
                                if (arrChar.length == 1 && arrChar[0] == 'N') {
                                    point_intent.putExtra("detach", true);
                                } else {
                                    for (int j = 0; j < recvMessage.length(); j++) {
                                        if (arrChar[j] == ' ') {
                                            String strx = new String(arrChar, 0, j);
                                            String stry = new String(arrChar, j + 1, recvMessage.length() - (j + 1));
                                            x = Integer.parseInt(strx);
                                            y = Integer.parseInt(stry);
                                        }
                                    }
                                    if (clickBluetooth(x, y) == false) {
                                        point_intent.putExtra("point_x", x);
                                        point_intent.putExtra("point_y", y);
                                    }
                                }
                                // TODO 문제가 있으면 여기를 주석처리 하세요
                                getCurrentClass();
                                if(current_class.equals("com.example.myapplication.Function.PaintActivity")){
                                    point_intent.putExtra("paint",true);
                                }
                                // 여기까지

                                sendBroadcast(point_intent);

                                readBufferPosition = 0;

                                Log.d(TAG, "recv message: " + recvMessage);
                                publishProgress(recvMessage);

                            } else {
                                readBuffer[readBufferPosition++] = b;
                            }
                        }
                    }
                } catch (IOException e) {

                    Log.e(TAG, "disconnected", e);
                    return false;
                }
            }

        }

       /* @Override
        protected void onProgressUpdate(String... recvMessage) {

            mConversationArrayAdapter.insert(mConnectedDeviceName + ": " + recvMessage[0], 0);
        }*/

        @Override
        protected void onPostExecute(Boolean isSucess) {
            super.onPostExecute(isSucess);

            if (!isSucess) {


                closeSocket();
                Log.d(TAG, "Device connection was lost");
                isConnectionError = true;
                showErrorDialog("Device connection was lost");
            }
        }

        @Override
        protected void onCancelled(Boolean aBoolean) {
            super.onCancelled(aBoolean);

            closeSocket();
        }

        void closeSocket() {

            try {

                mBluetoothSocket.close();
                Log.d(TAG, "close socket()");

            } catch (IOException e2) {

                Log.e(TAG, "unable to close() " +
                        " socket during connection failure", e2);
            }
        }

        void write(String msg) {

            msg += "\n";

            try {
                mOutputStream.write(msg.getBytes());
                mOutputStream.flush();
            } catch (IOException e) {
                Log.e(TAG, "Exception during send", e);
            }

            // mInputEditText.setText(" ");
        }

    }


    public void showPairedDevicesListDialog() {
        Set<BluetoothDevice> devices = mBluetoothAdapter.getBondedDevices();
        final BluetoothDevice[] pairedDevices = devices.toArray(new BluetoothDevice[0]);

        if (pairedDevices.length == 0) {
            showQuitDialog("No devices have been paired.\n"
                    + "You must pair it with another device.");
            return;
        }

        String[] items;
        items = new String[pairedDevices.length];
        boolean isreaspDetected = false;
        for (int i = 0; i < pairedDevices.length; i++) {
            items[i] = pairedDevices[i].getName();
            if (items[i].equals("raspberrypi")) {
                isreaspDetected = true;
                ConnectTask task = new ConnectTask(pairedDevices[i]);
                task.execute();

                sendBroadcast(new Intent("connection_success"));
                break;
            }
        }
        if (isreaspDetected == false) {
            toastHandler.post(new ToastRunnable("라즈베리파이의 블루투스를 활성화 해주세요."));
        }
    }


    public void showErrorDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quit");
        builder.setCancelable(false);
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                if (isConnectionError) {
                    isConnectionError = false;
                }
            }
        });
    }


    public void showQuitDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quit");
        builder.setCancelable(false);
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        // builder.create().show();
    }
}
