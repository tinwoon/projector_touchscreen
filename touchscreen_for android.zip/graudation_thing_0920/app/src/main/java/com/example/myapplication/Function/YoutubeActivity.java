package com.example.myapplication.Function;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.example.myapplication.R;

public class YoutubeActivity extends Activity {

    private int pointY;

    private WebView mWebView; // 웹뷰 선언
    private WebSettings mWebSettings; //웹뷰세팅
    private BroadcastReceiver br_youtubeScrollUp, br_youtubeScrollDown, br_getPoint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtube);

        init();

    }


    @Override
    protected void onResume() {
        super.onResume();
        if (br_youtubeScrollUp == null) {
            br_youtubeScrollUp = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    mWebView.scrollTo(0, pointY - 600); // 올라가게
                }
            };
        }

        if (br_youtubeScrollDown == null) {
            br_youtubeScrollDown = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    pointY += 600;
                    mWebView.scrollTo(0, pointY); // 내려가게
                }
            };
        }
        if (br_getPoint == null) {
            br_getPoint = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    int x = intent.getIntExtra("point_x", -1);
                    int y = intent.getIntExtra("point_y", -1);
                    long downTime = SystemClock.uptimeMillis();
                    long eventTime = SystemClock.uptimeMillis();
                    int metaState = 0;

                    if (x >= 0 && y >= 0) {
                        final MotionEvent motionEvent1 = MotionEvent.obtain(
                                downTime,
                                eventTime,
                                MotionEvent.ACTION_DOWN,
                                x,
                                y,
                                metaState
                        );

                        mWebView.dispatchTouchEvent(motionEvent1);
                    }

                }
            };
        }

        registerReceiver(br_getPoint, new IntentFilter("point"));
        registerReceiver(br_youtubeScrollUp, new IntentFilter("youtube_Scroll_Up"));
        registerReceiver(br_youtubeScrollDown, new IntentFilter("youtube_Scroll_Down"));

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (br_youtubeScrollUp != null) {
            unregisterReceiver(br_youtubeScrollUp);
        }
        if (br_youtubeScrollDown != null) {
            unregisterReceiver(br_youtubeScrollDown);
        }
        if (br_getPoint != null) {
            unregisterReceiver(br_getPoint);
        }
    }

    public void init() {
        pointY = 0;
        mWebView = (WebView) findViewById(R.id.youtube_webView);

        initWebview();
    }

    public void initWebview() {
        mWebView.setWebViewClient(new WebViewClient()); // 클릭시 새창 안뜨게
        mWebSettings = mWebView.getSettings(); //세부 세팅 등록
        mWebSettings.setJavaScriptEnabled(true); // 웹페이지 자바스클비트 허용 여부
        mWebSettings.setSupportMultipleWindows(false); // 새창 띄우기 허용 여부
        mWebSettings.setJavaScriptCanOpenWindowsAutomatically(false); // 자바스크립트 새창 띄우기(멀티뷰) 허용 여부
        mWebSettings.setLoadWithOverviewMode(true); // 메타태그 허용 여부
        mWebSettings.setUseWideViewPort(true); // 화면 사이즈 맞추기 허용 여부
        mWebSettings.setSupportZoom(false); // 화면 줌 허용 여부
        mWebSettings.setBuiltInZoomControls(false); // 화면 확대 축소 허용 여부
        mWebSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN); // 컨텐츠 사이즈 맞추기
        mWebSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); // 브라우저 캐시 허용 여부
        mWebSettings.setDomStorageEnabled(true); // 로컬저장소 허용 여부

        mWebView.loadUrl("https://youtube.com"); // 웹뷰에 표시할 웹사이트 주소, 웹뷰 시작
    }
}