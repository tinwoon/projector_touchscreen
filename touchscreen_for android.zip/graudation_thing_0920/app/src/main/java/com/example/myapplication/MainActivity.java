package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class MainActivity extends Activity {

    private final String PackageName = "com.infraware.office.reader.team";
    private BroadcastReceiver br_main;
    private TextView txt_connection;

    private Intent ppt_intent;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startService(new Intent(this, AlwaysTopServiceTouch.class));
        ppt_intent = this.getPackageManager().getLaunchIntentForPackage(PackageName);

        ActivityCompat.requestPermissions(this, new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(getApplicationContext())) {
                checkOverlayPermission();
            }
        }

        init();
    }

    private void init() {
        txt_connection = findViewById(R.id.txt_main_connection);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (br_main == null) {
            br_main = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    txt_connection.setText("연결\t완료");
                    txt_connection.setTextColor(Color.BLUE);
                }
            };
        }
        registerReceiver(br_main, new IntentFilter("connection_success"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void checkOverlayPermission() {

        try {

            Uri uri = Uri.parse("package:" + getPackageName());

            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, uri);

            startActivityForResult(intent, 5469);

        } catch (Exception e) {

            //toast(e.toString());

        }

    }
}
