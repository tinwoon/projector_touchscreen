package com.example.myapplication.Dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.R;


public class PdfCustomDialog {
    private Dialog dialog;
    private Context context;
    private Button btn_pdfOk, btn_pdfCancle;
    private EditText edittxt_url;

    Intent pdf_intent = new Intent("set_pdf_url");

    public PdfCustomDialog(Context context) {
        this.context = context;
    }


    // 호출할 다이얼로그 함수를 정의한다.
    public void createDialog() {
        {
            dialog = new Dialog(context);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.pdf_url_custom_dialog);

            resizeDisplay();
            init();

            dialog.show();
        }

        btn_pdfOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pdf_url = edittxt_url.getText().toString();
                if (pdf_url.length() > 0) {
                    pdf_intent.putExtra("pdf_url", pdf_url);
                    pdf_intent.putExtra("success", 1);
                    context.sendBroadcast(pdf_intent);

                    dialog.dismiss();
                } else{
                    Toast.makeText(context, "url을 입력해주세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_pdfCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pdf_intent.putExtra("success", 0);
                context.sendBroadcast(pdf_intent);
                dialog.dismiss();
            }
        });
    }

    private void resizeDisplay() {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();

        WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = (int) (dm.widthPixels * 0.8);
        params.height = WindowManager.LayoutParams.WRAP_CONTENT;
        dialog.getWindow().setAttributes(params);
    }

    private void init() {

        btn_pdfOk = dialog.findViewById(R.id.btn_pdf_ok);
        btn_pdfCancle = dialog.findViewById(R.id.btn_pdf_cancle);
        edittxt_url = dialog.findViewById(R.id.edittxt_url);

    }
}
