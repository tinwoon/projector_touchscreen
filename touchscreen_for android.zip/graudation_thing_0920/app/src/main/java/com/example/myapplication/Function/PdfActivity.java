package com.example.myapplication.Function;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.example.myapplication.Dialog.PdfCustomDialog;
import com.example.myapplication.R;

public class PdfActivity extends Activity {

    private WebView mWebView; // 웹뷰 선언
    private WebSettings mWebSettings; //웹뷰세팅

    private int pointx = 0;
    private int pointy = 0;

    private boolean isTouched = false;

    private BroadcastReceiver br_getClose, br_getPoint;

    public PdfActivity() {
    }

    // TODO pdf 열려있는 부분에서는 스크롤 안 됨

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ppt);
/*
        PdfCustomDialog pdfDialog = new PdfCustomDialog(this);
        pdfDialog.createDialog();*/

        init();

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (br_getPoint == null) {
            br_getPoint = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {

                    boolean isPaint = intent.getBooleanExtra("paint", false);
                    boolean isDetached = intent.getBooleanExtra("detach", false);
                    long downTime = SystemClock.uptimeMillis();
                    long eventTime = SystemClock.uptimeMillis();

                    int metaState = 0;

                    if (!isPaint) {
                        if (isDetached == true && pointx > 0 && pointy > 0) {
                            final MotionEvent motionEventUp = MotionEvent.obtain(
                                    downTime,
                                    eventTime,
                                    MotionEvent.ACTION_UP,
                                    pointx,
                                    pointy,
                                    metaState
                            );
                            mWebView.dispatchTouchEvent(motionEventUp);
                            isTouched = false;
                        } else if (isDetached == false && isTouched == false) {

                            pointx = intent.getIntExtra("point_x", -1);
                            pointy = intent.getIntExtra("point_y", -1);
                            if (pointx > 0 && pointy > 0) {
                                isTouched = true;
                                final MotionEvent motionEventDown = MotionEvent.obtain(
                                        downTime,
                                        eventTime,
                                        MotionEvent.ACTION_DOWN,
                                        pointx,
                                        pointy,
                                        metaState
                                );
                                mWebView.dispatchTouchEvent(motionEventDown);
                            }
                        }
                        if (isDetached == false && isTouched == true) {

                            pointx = intent.getIntExtra("point_x", -1);
                            pointy = intent.getIntExtra("point_y", -1);
                            if (pointx > 0 && pointy > 0) {
                                final MotionEvent motionEventMove = MotionEvent.obtain(
                                        downTime,
                                        eventTime,
                                        MotionEvent.ACTION_MOVE,
                                        pointx,
                                        pointy,
                                        metaState
                                );
                                mWebView.dispatchTouchEvent(motionEventMove);
                            }
                        }
                    }
                }
            };
        }


        if (br_getClose == null) {
            br_getClose = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    finish();
                    overridePendingTransition(0, 0);
                }
            };
        }


        registerReceiver(br_getPoint, new IntentFilter("point"));
        registerReceiver(br_getClose, new IntentFilter("pdfActivity_close"));

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (br_getPoint != null) {
            unregisterReceiver(br_getPoint);
        }
        if (br_getClose != null) {
            unregisterReceiver(br_getClose);
        }
    }


    public void init() {

        mWebView = (WebView) findViewById(R.id.ppt_webView);

        //웹뷰 스크롤 설정

        mWebView.setHorizontalScrollBarEnabled(true);
        mWebView.setVerticalScrollBarEnabled(true);

        initWebview();
    }

    public void initWebview() {
        mWebView.setWebViewClient(new WebViewClient()); // 클릭시 새창 안뜨게
        mWebSettings = mWebView.getSettings(); //세부 세팅 등록
        mWebSettings.setJavaScriptEnabled(true); // 웹페이지 자바스클비트 허용 여부
        mWebSettings.setSupportMultipleWindows(false); // 새창 띄우기 허용 여부
        mWebSettings.setJavaScriptCanOpenWindowsAutomatically(false); // 자바스크립트 새창 띄우기(멀티뷰) 허용 여부
        mWebSettings.setLoadWithOverviewMode(true); // 메타태그 허용 여부
        mWebSettings.setUseWideViewPort(true); // 화면 사이즈 맞추기 허용 여부
        mWebSettings.setSupportZoom(false); // 화면 줌 허용 여부
        mWebSettings.setBuiltInZoomControls(false); // 화면 확대 축소 허용 여부
        mWebSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN); // 컨텐츠 사이즈 맞추기
        mWebSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); // 브라우저 캐시 허용 여부
        mWebSettings.setDomStorageEnabled(true); // 로컬저장소 허용 여부
        mWebView.loadUrl("https://drive.google.com/file/d/1a3Y-aT7-oCX4RXukZ6prJ5Ax84Zk3oLJ/view?usp=sharing");
    }
}

