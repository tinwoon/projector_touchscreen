package com.example.myapplication.Function;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.example.myapplication.R;

import java.util.Random;
import java.util.Timer;

public class NaverActivity extends Activity {

    // 테스트용 변수

    private int pointY;

    private WebView mWebView; // 웹뷰 선언
    private WebSettings mWebSettings; //웹뷰세팅

    private BroadcastReceiver br_naverScrollUp, br_naverScrollDown, br_getPoint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_naver);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (br_naverScrollUp != null) {
            unregisterReceiver(br_naverScrollUp);
        }
        if (br_naverScrollDown != null) {
            unregisterReceiver(br_naverScrollDown);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (br_naverScrollUp == null) {
            br_naverScrollUp = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    mWebView.scrollTo(0, pointY - 600); // 올라가게
                }
            };
        }

        if (br_naverScrollDown == null) {
            br_naverScrollDown = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    pointY += 600;
                    mWebView.scrollTo(0, pointY); // 내려가게
                }
            };
        }
        if (br_getPoint == null) {
            br_getPoint = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    int x = intent.getIntExtra("point_x", -1);
                    int y = intent.getIntExtra("point_y", -1);
                    long downTime = SystemClock.uptimeMillis();
                    long eventTime = SystemClock.uptimeMillis();
                    int metaState = 0;

                    if (x >= 0 && y >= 0) {
                        final MotionEvent motionEvent1 = MotionEvent.obtain(
                                downTime,
                                eventTime,
                                MotionEvent.ACTION_DOWN,
                                x,
                                y,
                                metaState
                        );

                        mWebView.dispatchTouchEvent(motionEvent1);
                    }

                }
            };
        }

        registerReceiver(br_getPoint, new IntentFilter("point"));
        registerReceiver(br_naverScrollUp, new IntentFilter("naver_Scroll_Up"));
        registerReceiver(br_naverScrollDown, new IntentFilter("naver_Scroll_Down"));

    }

    @SuppressLint("ClickableViewAccessibility")
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onStart() {
        super.onStart();

        // 변수 초기화
        init();

       /*// Web 터치 좌표 받아옴
        mWebView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Toast.makeText(getApplication(), "X : " + event.getX() + " Y : " + event.getY(), Toast.LENGTH_SHORT).show();
                return false;
            }
        });*/
    }

    public void init() {


        pointY = 0;

        initWebview();
    }

    public void initWebview() {
        mWebView = (WebView) findViewById(R.id.naver_webView);

        mWebView.setWebViewClient(new WebViewClient()); // 클릭시 새창 안뜨게
        mWebSettings = mWebView.getSettings(); //세부 세팅 등록
        mWebSettings.setJavaScriptEnabled(true); // 웹페이지 자바스클비트 허용 여부
        mWebSettings.setSupportMultipleWindows(false); // 새창 띄우기 허용 여부
        mWebSettings.setJavaScriptCanOpenWindowsAutomatically(false); // 자바스크립트 새창 띄우기(멀티뷰) 허용 여부
        mWebSettings.setLoadWithOverviewMode(true); // 메타태그 허용 여부
        mWebSettings.setUseWideViewPort(true); // 화면 사이즈 맞추기 허용 여부
        mWebSettings.setSupportZoom(false); // 화면 줌 허용 여부
        mWebSettings.setBuiltInZoomControls(false); // 화면 확대 축소 허용 여부
        mWebSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN); // 컨텐츠 사이즈 맞추기
        mWebSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); // 브라우저 캐시 허용 여부
        mWebSettings.setDomStorageEnabled(true); // 로컬저장소 허용 여부

        mWebView.loadUrl("https://naver.com"); // 웹뷰에 표시할 웹사이트 주소, 웹뷰 시작
    }

}
